from setuptools import setup
from Cython.Build import cythonize
setup(
    ext_modules=cythonize("/storage/emulated/0/Download/deploy_work/pkg_x86_64/loader.py", compiler_directives={'language_level': '3'}),
    script_args=["build_ext", "--inplace"]
)
